g++ -m32 BioStarGatewayClient.cpp -o BioStarGatewayClient && ./BioStarGatewayClient
