#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BIOSTAR_GATEWAY_SERVICE_PORT 1471

using namespace std;

int main(int argc, char ** argv) {
   int nBioStarClientSocket = -1;
   struct sockaddr_in oBioStarServiceSocket;

   try {
      if (argc >= 3) {
         nBioStarClientSocket = socket(AF_INET, SOCK_STREAM, 0);
         if (nBioStarClientSocket != -1) {
            oBioStarServiceSocket.sin_addr.s_addr = inet_addr(argv[1]);
  	    oBioStarServiceSocket.sin_family = AF_INET;
	    oBioStarServiceSocket.sin_port = htons(BIOSTAR_GATEWAY_SERVICE_PORT);

            struct timeval tv;
            tv.tv_sec = 30;
            tv.tv_usec = 0;
	    setsockopt(nBioStarClientSocket, SOL_SOCKET, SO_RCVTIMEO, (const char*) &tv, sizeof tv);

            if (connect(nBioStarClientSocket, (struct sockaddr *) &oBioStarServiceSocket, sizeof(oBioStarServiceSocket)) >= 0) {
               string sCommand = "";
               for(int i = 2; i < argc; i++) {
                  if (i == 2) sCommand = string(argv[i]);
                  else sCommand += " " + string(argv[i]);
               }
               
               sCommand += "<EOC>";

               if (send(nBioStarClientSocket, sCommand.c_str(), strlen(sCommand.c_str()), 0) >= 0) {
                  char sBioStarServiceSocketData[32768];
		  string sBioStarServiceSocketDataOutput = "";

                  bool bBioStarServiceSocketDataAllCommand = false;
                  for(;!bBioStarServiceSocketDataAllCommand;) {
                     try {
                        int nBioStarServiceSocketBytesRecieve = recv(nBioStarClientSocket, sBioStarServiceSocketData, 32768, 0);
                        sBioStarServiceSocketDataOutput += string(sBioStarServiceSocketData).substr(0, nBioStarServiceSocketBytesRecieve);
                        
			if (sBioStarServiceSocketDataOutput.find("<EOC>") != string::npos) {
                           bBioStarServiceSocketDataAllCommand = true;
                        }
                     } catch (exception& oException) {
                        bBioStarServiceSocketDataAllCommand = true;
                     }
                  }

                  if (sBioStarServiceSocketDataOutput.find("<EOC>") != string::npos) {
                     sBioStarServiceSocketDataOutput.erase(sBioStarServiceSocketDataOutput.find("<EOC>"), strlen("<EOC>"));
                     cout << sBioStarServiceSocketDataOutput;
                  }
                  else cout << sBioStarServiceSocketDataOutput;
               }
               else cout << "[ ERROR ] El cliente no ha podido enviar el comando " << sCommand << " al socket remoto.\r\n" << endl; 
               
               close(nBioStarClientSocket);
            }
            else cout << "[ ERROR ] El cliente no ha podido establecer conexion con la direccion IP remota: " << argv[1] << " y puerto: " << BIOSTAR_GATEWAY_SERVICE_PORT << "\r\n" << endl;
         }
         else cout << "[ ERROR ] El cliente no ha podido crear el socket\r\n" << endl;
      } 
      else cout << "[ ERROR ] El numero de argumentos es incorrecto.\r\n\n\t* Argumentos: IP_Address Command\r\n" << endl;
   } catch(exception& oException) {
      if (nBioStarClientSocket != -1) close(nBioStarClientSocket);

      cout << oException.what() << endl;  
   }
}