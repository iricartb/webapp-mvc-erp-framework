g++ -m32 main.cpp -o BioStarGetInfo lib/libBS_SDK_V2.so -lpthread && ./BioStarGetInfo
