#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <iostream>

#include "include/BS_API.h"
#include "include/BS_Errno.h"

#define TRUE 1
#define FALSE 0

#define SUCCESS_CONNECT_DEVICE_STATUS 0
#define ERR_CONNECT_DEVICE_STATUS_1 -1 
#define ERR_CONNECT_DEVICE_STATUS_2 -2 
#define ERR_CONNECT_DEVICE_STATUS_3 -3
   
int initialize();
int connectDevice(char * sDeviceIPAddress, int nDevicePort);
void disconnectDevice();
long convertDateToUnixTimestamp(char * sDate);
char * convertUnixTimestampToDate(long nSeconds);

void * oBS2Context = NULL;
char * sInputDeviceIPAddress, * sInputStartDate;
int nInputDevicePort;
uint32_t nDeviceId = 0;

using namespace std;

int main(int argc, char ** argv) {
   int nResult;
   
   try {
      if (argc == 4) {
         sInputDeviceIPAddress = argv[1];
         nInputDevicePort = atoi(argv[2]);
         sInputStartDate = argv[3];
         
         if (initialize()) {
            int nConnectDeviceStatus = connectDevice(sInputDeviceIPAddress, nInputDevicePort);
            
            if (nConnectDeviceStatus == SUCCESS_CONNECT_DEVICE_STATUS) {
               nResult = BS2_SetDeviceTime(oBS2Context, nDeviceId, convertDateToUnixTimestamp(sInputStartDate));
               if (nResult == BS_SDK_SUCCESS) {
                  cout << "[ SUCCESS ] Se ha establecido la hora en el dispositivo con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ".\r\n" << endl; 
               }
               else cout << "[ ERROR ] No se ha podido establecer la hora en el dispositivo con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ".\r\nCodigo de Error: " << nResult << "\r\n" << endl;    
               
               disconnectDevice();
            }
            else {
               if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_1) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". La funcion BS2_ConnectDeviceViaIP ha fallado.\r\n" << endl;    
               else if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_2) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". La funcion BS2_GetDeviceInfo ha fallado.\r\n" << endl;    
               else if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_3) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". El dispositivo no es un Biostar Entry Plus.\r\n" << endl;     
            }
            
            BS2_ReleaseContext(oBS2Context);
         }
         else cout << "[ ERROR ] No se ha podido inicializar el Biostar.\r\n" << endl;
      }
      else cout << "[ ERROR ] El numero de argumentos es incorrecto.\r\n\n\t* Argumentos: IP_Address Port StartDate\r\n" << endl;
   } catch(exception& oException) {
      cout << oException.what() << endl;  
   }
}

int initialize() {
   oBS2Context = BS2_AllocateContext();   
   
   if (oBS2Context != NULL) {
      int nResult = BS2_Initialize(oBS2Context);
      
      if (nResult == BS_SDK_SUCCESS) return TRUE;
      else return FALSE;
   } 
}

int connectDevice(char * sDeviceIPAddress, int nDevicePort) { 
   BS2SimpleDeviceInfo oDeviceInformation;
   int nResult = BS2_ConnectDeviceViaIP(oBS2Context, sDeviceIPAddress, nDevicePort, &nDeviceId);
   
   if (nResult == BS_SDK_SUCCESS) {
      nResult = BS2_GetDeviceInfo(oBS2Context, nDeviceId, &oDeviceInformation);
      if (nResult == BS_SDK_SUCCESS) {
         if ((oDeviceInformation.type == BS2_DEVICE_TYPE_BIOENTRY_PLUS) || (oDeviceInformation.type == BS2_DEVICE_TYPE_BIOLITE_NET)) {
            return SUCCESS_CONNECT_DEVICE_STATUS;
         }   
         else return ERR_CONNECT_DEVICE_STATUS_3;
      }
      else return ERR_CONNECT_DEVICE_STATUS_2;
   }
   else return ERR_CONNECT_DEVICE_STATUS_1;
}

void disconnectDevice() { 
   BS2_DisconnectDevice(oBS2Context, nDeviceId);   
}

long convertDateToUnixTimestamp(char * sDate) {
   struct tm oTimeStamp;

   strptime(sDate, "%Y-%m-%d %H:%M:%S", &oTimeStamp);
   
   oTimeStamp.tm_sec += 3600;
   
   return mktime(&oTimeStamp);
}

char * convertUnixTimestampToDate(long nSeconds) {
   struct tm oTimeStamp;
   char * sDate = (char *) malloc(sizeof(char) * 20);
   
   oTimeStamp.tm_sec += nSeconds;
   
   strftime(sDate, sizeof(sDate), "%Y-%m-%d %H:%M:%S", &oTimeStamp);

   return sDate;
}