/*
 * BS2EventLogFilter.h
 *
 *  Created on: 2015. 5. 18.
 *      Author: scpark
 */

#ifndef CORE_JNI_SRC_BSCOMMON_DATA_BS2EVENTLOGFILTER_H_
#define CORE_JNI_SRC_BSCOMMON_DATA_BS2EVENTLOGFILTER_H_

#include "../BS2Types.h"

typedef struct
{
    BS2_USER_ID userID;
    BS2_TIMESTAMP start;
    BS2_TIMESTAMP end;
    BS2_EVENT_CODE event;
    uint8_t tnakey;
    uint8_t reserved[1];
}EventLogFilter;

#endif /* CORE_JNI_SRC_BSCOMMON_DATA_BS2EVENTLOGFILTER_H_ */
