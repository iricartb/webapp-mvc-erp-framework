/**
 *  Card Configuration Definitions
 *
 *  @author jylee@suprema.co.kr
 *  @see    
 */

/*  
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 * 
 *  This software is the confidential and proprietary information of 
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __BS2_CARD_CONFIG_H__
#define __BS2_CARD_CONFIG_H__

#include "../BS2Types.h"

/**
 *  Card Config constants
 */
enum {
	BS2_CARD_KEY_SIZE		= 32,
	BS2_CARD_MAGIC_NO		= 0x1F1F1F1F,
	BS2_CARD_MAX_TEMPLATES	= 4,	///< Maximum number of templates for Smart Card
};

/**
 *	BS2_CARD_DATA_TYPE
 */
enum {
	BS2_CARD_DATA_BINARY	= 0,
	BS2_CARD_DATA_ASCII		= 1,
	BS2_CARD_DATA_UTF16		= 2,
	BS2_CARD_DATA_BCD		= 3,
};

typedef uint8_t BS2_CARD_DATA_TYPE;

/**
 *  BS2_CARD_BYTE_ORDER
 */
enum {
	BS2_CARD_BYTE_ORDER_MSB	= 0,
	BS2_CARD_BYTE_ORDER_LSB	= 1,
};

typedef uint8_t BS2_CARD_BYTE_ORDER;

/**
 *  BS2CardConfig
 */
typedef struct {
	// CSN
	BS2_CARD_BYTE_ORDER	byteOrder;		///< 1 byte
	BS2_BOOL	useWiegandFormat;		///< 1 byte
	uint8_t reserved[2];				///< 2 bytes (packing)

	// Smart Card
	uint8_t primaryKey[BS2_CARD_KEY_SIZE];		///< 32 bytes
	uint8_t secondaryKey[BS2_CARD_KEY_SIZE];	///< 32 bytes
	BS2_BOOL useSecondaryKey;			///< 1 byte	
	uint8_t reserved2[1];				///< 1 byte (packing)
	uint16_t startBlockIndex;			///< 2 bytes
	uint8_t appID;						///< 1 byte
	uint8_t fileID;						///< 1 byte
	uint8_t reserved3[2];				///< 2 bytes (packing)

	// Secure Credential
	uint8_t		fieldStart[4];			///< 4 bytes
	uint8_t		fieldEnd[4];			///< 4 bytes
	BS2_CARD_DATA_TYPE	dataType;		///< 1 byte
	uint8_t reserved4[3];				///< 3 bytes (packing)
	
	uint8_t reserved5[32];				///< 32 bytes (reserved)
} BS2CardConfig;

#endif	// __BS2_CARD_CONFIG_H__