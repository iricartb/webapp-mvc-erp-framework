/**
 *  	Error Codes
 *
 *  	@author sjlee@suprema.co.kr
 *  	@see
 */

/*
 *  Copyright (c) 2012 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef ERROR_H_INCLUDED
#define ERROR_H_INCLUDED

const int BS_SUCCESS = 1;
const int BS_DURESS_SUCCESS = 2;
const int BS_FIRST_AUTH_SUCCESS = 3;
const int BS_SECOND_AUTH_SUCCESS = 4;
const int BS_DUAL_AUTH_SUCCESS = 5;

// Driver errors
const int BS_ERR_FROM_DEVICE_DRIVER = -1;

//
// Communication errors
//
const int BS_ERR_CANNOT_OPEN_SOCKET = -101;
const int BS_ERR_CANNOT_CONNECT_SOCKET = -102;
const int BS_ERR_CANNOT_LISTEN_SOCKET = -103;
const int BS_ERR_CANNOT_ACCEPT_SOCKET = -104;
const int BS_ERR_CANNOT_READ_SOCKET = -105;
const int BS_ERR_CANNOT_WRITE_SOCKET = -106;
const int BS_ERR_SOCKET_IS_NOT_CONNECTED = -107;
const int BS_ERR_SOCKET_IS_NOT_OPEN = -108;
const int BS_ERR_SOCKET_IS_NOT_LISTENED = -109;
const int BS_ERR_SOCKET_IN_PROGRESS = -110;

//
// Packet errors
//
const int BS_ERR_INVALID_PARAM = -200;
const int BS_ERR_INVALID_PACKET = -201;
const int BS_ERR_INVALID_DEVICE_ID = -202;
const int BS_ERR_INVALID_DEVICE_TYPE = -203;
const int BS_ERR_PACKET_CHECKSUM = -204;
const int BS_ERR_PACKET_INDEX = -205;
const int BS_ERR_PACKET_COMMAND = -206;
const int BS_ERR_PACKET_SEQUENCE = -207;
const int BS_ERR_NO_PACKET = -209;

//
// Fingerprint errors
//
const int BS_ERR_EXTRACTION_FAIL = -300;
const int BS_ERR_VERIFY_FAIL = -301;
const int BS_ERR_IDENTIFY_FAIL = -302;
const int BS_ERR_IDENTIFY_TIMEOUT = -303;
const int BS_ERR_FINGERPRINT_CAPTURE_FAIL = -304;
const int BS_ERR_FINGERPRINT_SCAN_TIMEOUT = -305;
const int BS_ERR_FINGERPRINT_SCAN_CANCELLED = -306;
const int BS_ERR_NOT_SAME_FINGERPRINT = -307;
const int BS_ERR_EXTRACTION_LOW_QUALITY = -308;
const int BS_ERR_CAPTURE_LOW_QUALITY = -309;
const int BS_ERR_CANNOT_FIND_FINGERPRINT = -310;

//
// File I/O errors
//
const int BS_ERR_CANNOT_OPEN_DIR = -400;
const int BS_ERR_CANNOT_OPEN_FILE = -401;
const int BS_ERR_CANNOT_WRITE_FILE = -402;
const int BS_ERR_CANNOT_SEEK_FILE = -403;
const int BS_ERR_CANNOT_READ_FILE = -404;
const int BS_ERR_CANNOT_GET_STAT = -405;
const int BS_ERR_CANNOT_GET_SYSINFO = -406;
const int BS_ERR_DATA_MISMATCH = -407;

//
// I/O errors
//
const int BS_ERR_INVALID_RELAY = -500;
const int BS_ERR_CANNOT_WRITE_IO_PACKET = -501;
const int BS_ERR_CANNOT_READ_IO_PACKET = -502;
const int BS_ERR_CANNOT_READ_INPUT = -503;
const int BS_ERR_READ_INPUT_TIMEOUT = -504;
const int BS_ERR_CANNOT_ENABLE_INPUT = -505;
const int BS_ERR_CANNOT_SET_INPUT_DURATION = -506;
const int BS_ERR_INVALID_PORT = -507;
const int BS_ERR_INVALID_INTERPHONE_TYPE = -508;

const int BS_ERR_INVALID_LCD_PARAM = -510;
const int BS_ERR_CANNOT_WRITE_LCD_PACKET = -511;
const int BS_ERR_CANNOT_READ_LCD_PACKET = -512;
const int BS_ERR_INVALID_LCD_PACKET = -513;

const int BS_ERR_INPUT_QUEUE_FULL = -520;
const int BS_ERR_WIEGAND_QUEUE_FULL = -521;
const int BS_ERR_MISC_INPUT_QUEUE_FULL = -522;
const int BS_ERR_WIEGAND_DATA_QUEUE_FULL = -523;
const int BS_ERR_WIEGAND_DATA_QUEUE_EMPTY = -524;

//
// Util errors
//
const int BS_ERR_NOT_SUPPORTED = -600;
const int BS_ERR_TIMEOUT = -601;

//
// Database errors
//
const int BS_ERR_INVALID_DATA_FILE = -700;
const int BS_ERR_TOO_LARGE_DATA_FOR_SLOT = -701;
const int BS_ERR_INVALID_SLOT_NO = -702;
const int BS_ERR_INVALID_SLOT_DATA = -703;
const int BS_ERR_CANNOT_INIT_DB = -704;
const int BS_ERR_DUPLICATE_ID = -705;
const int BS_ERR_USER_FULL = -706;
const int BS_ERR_DUPLICATE_TEMPLATE = -707;
const int BS_ERR_FINGERPRINT_FULL = -708;
const int BS_ERR_DUPLICATE_CARD = -709;
const int BS_ERR_CARD_FULL = -710;
const int BS_ERR_NO_VALID_HDR_FILE = -711;
const int BS_ERR_INVALID_LOG_FILE = -712;
const int BS_ERR_CANNOT_FIND_USER = -714;
const int BS_ERR_ACCESS_LEVEL_FULL = -715;
const int BS_ERR_INVALID_USER_ID = -716;
const int BS_ERR_BLACKLIST_FULL = -717;
const int BS_ERR_USER_NAME_FULL = -718;
const int BS_ERR_USER_IMAGE_FULL = -719;
const int BS_ERR_USER_IMAGE_SIZE_TOO_BIG = -720;
const int BS_ERR_SLOT_DATA_CHECKSUM = -721;
const int BS_ERR_CANNOT_UPDATE_FINGERPRINT = -722;
const int BS_ERR_INVALID_TEMPLATE_NUM = -723;
const int BS_ERR_NO_ADMIN_USER = -724;
const int BS_ERR_CANNOT_FIND_LOG = -725;
const int BS_ERR_DOOR_SCHEDULE_FULL = -726;
const int BS_ERR_DB_SLOT_FULL = -727;
const int BS_ERR_ACCESS_GROUP_FULL = -728;
const int BS_ERR_ACCESS_SCHEDULE_FULL = -730;
const int BS_ERR_HOLIDAY_GROUP_FULL = -731;
const int BS_ERR_HOLIDAY_FULL = -732;
const int BS_ERR_TIME_PERIOD_FULL = -733;
const int BS_ERR_NO_CREDENTIAL = -734;
const int BS_ERR_NO_BIOMETRIC_CREDENTIAL = -735;
const int BS_ERR_NO_CARD_CREDENTIAL = -736;
const int BS_ERR_NO_PIN_CREDENTIAL = -737;
const int BS_ERR_NO_BIOMETRIC_PIN_CREDENTIAL = -738;
const int BS_ERR_NO_USER_NAME = -739;
const int BS_ERR_NO_USER_IMAGE = -740;
const int BS_ERR_READER_FULL = -741;
const int BS_ERR_TIMER_CANCELED = -741;
const int BS_ERR_CACHE_MISSED = -742;
const int BS_ERR_OPERATOR_FULL = -743;

//
// Config errors
//
const int BS_ERR_INVALID_CONFIG = -800;
const int BS_ERR_CANNOT_OPEN_CONFIG_FILE = -801;
const int BS_ERR_CANNOT_READ_CONFIG_FILE = -802;
const int BS_ERR_INVALID_CONFIG_FILE = -803;
const int BS_ERR_INVALID_CONFIG_DATA = -804;
const int BS_ERR_CANNOT_WRITE_CONFIG_FILE = -805;
const int BS_ERR_INVALID_CONFIG_INDEX = -806;


//
// Device errors
//
const int BS_ERR_CANNOT_SCAN_FINGER = -900;
const int BS_ERR_CANNOT_SCAN_CARD = -901;
const int BS_ERR_CANNOT_OPEN_RTC = -902;
const int BS_ERR_CANNOT_SET_RTC = -903;
const int BS_ERR_CANNOT_GET_RTC = -904;
const int BS_ERR_CANNOT_SET_LED = -905;
const int BS_ERR_CANNOT_OPEN_DEVICE_DRIVER = -906;
const int BS_ERR_CANNOT_FIND_DEVICE = -907;

//
// Door errors
//
const int BS_ERR_CANNOT_FIND_DOOR = -1000;
const int BS_ERR_DOOR_FULL = -1001;
const int BS_ERR_CANNOT_LOCK_DOOR = -1002;
const int BS_ERR_CANNOT_UNLOCK_DOOR = -1003;

//
// Access control errors
//
const int BS_ERR_ACCESS_RULE_VIOLATION = -1100;
const int BS_ERR_DISABLED = -1101;
const int BS_ERR_NOT_YET_VALID = -1102;
const int BS_ERR_EXPIRED = -1103;
const int BS_ERR_BLACKLIST = -1104;
const int BS_ERR_CANNOT_FIND_ACCESS_GROUP = -1105;
const int BS_ERR_CANNOT_FIND_ACCESS_LEVEL = -1106;
const int BS_ERR_CANNOT_FIND_ACCESS_SCHEDULE = -1107;
const int BS_ERR_CANNOT_FIND_HOLIDAY_GROUP = -1108;
const int BS_ERR_CANNOT_FIND_BLACKLIST = -1109;

const int BS_ERR_AUTH_TIMEOUT = -1110;
const int BS_ERR_DUAL_AUTH_TIMEOUT = -1111;
const int BS_ERR_INVALID_AUTH_MODE = -1112;
const int BS_ERR_AUTH_UNEXPECTED_USER = -1113;
const int BS_ERR_AUTH_UNEXPECTED_CREDENTIAL = -1114;
const int BS_ERR_DUAL_AUTH_FAIL = -1115;
const int BS_BIOMETRIC_AUTH_REQUIRED = -1116;
const int BS_CARD_AUTH_REQUIRED = -1117;
const int BS_PIN_AUTH_REQUIRED = -1118;
const int BS_BIOMETRIC_OR_PIN_AUTH_REQUIRED = -1119;
const int BS_TNA_CODE_REQUIRED = -1120;

// Zone errors
const int BS_ERR_CANNOT_FIND_ZONE = -1200;
const int BS_ERR_ZONE_FULL = -1201;
const int BS_ERR_HARD_APB_VIOLATION = -1202;
const int BS_ERR_SOFT_APB_VIOLATION = -1203;
const int BS_ERR_HARD_TIMED_APB_VIOLATION = -1204;
const int BS_ERR_SOFT_TIMED_APB_VIOLATION = -1205;
const int BS_ERR_FORCED_LOCK_VIOLATION = -1206;
#if 0
const int BS_ERR_FORCED_UNLOCK_VIOLATION = -1207;
#endif
const int BS_ERR_SET_FIRE_ALARM = -1208;

// Card errors
const int BS_ERR_CARD_IO = -1300;
const int BS_ERR_CARD_INIT_FAIL = -1301;
const int BS_ERR_CARD_NOT_ACTIVATED = -1302;
const int BS_ERR_CARD_CANNOT_READ_DATA = -1303;
const int BS_ERR_CARD_CIS_CRC = -1304;
const int BS_ERR_CARD_CANNOT_WRITE_DATA = -1305;
const int BS_ERR_CARD_READ_TIMEOUT = -1306;
const int BS_ERR_CARD_READ_CANCELLED = -1307;
const int BS_ERR_CARD_CANNOT_SEND_DATA = -1308;
const int BS_ERR_CANNOT_FIND_CARD = -1310;

// Operation
const int BS_ERR_INVALID_PASSWORD = -1400;

// System
const int BS_ERR_CAMERA_INIT_FAIL = -1500;
const int BS_ERR_JPEG_ENCODER_INIT_FAIL = -1501;
const int BS_ERR_CANNOT_ENCODE_JPEG = -1502;
const int BS_ERR_JPEG_ENCODER_NOT_INITIALIZED = -1503;
const int BS_ERR_JPEG_ENCODER_DEINIT_FAIL = -1504;
const int BS_ERR_CAMERA_CAPTURE_TIMEOUT = -1505;

//
// ETC.
//
const int BS_ERR_FILE_IO = -2000;
const int BS_ERR_ALLOC_MEM = -2002;
const int BS_ERR_CANNOT_UPGRADE = -2003;

#endif // ERROR_H_INCLUDED
