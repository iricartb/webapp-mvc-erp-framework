/*
 * BS2WiegandDeviceConfig.h
 *
 *  Created on: 2015. 3. 16.
 *      Author: yhlee
 */

/*
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */
 
#ifndef __BS2_WIEGAND_DEVICE_CONFIG_H__
#define __BS2_WIEGAND_DEVICE_CONFIG_H__

#include "../BS2Types.h"

/**
 *  BS2WiegandTamper
 */
typedef struct{
	BS2_DEVICE_ID	deviceID;		///< 4 bytes
	uint8_t			portID;			///< 1 byte : 1 ~ 16
	uint8_t			switchType;		///< 1 byte : 0 = N/O, 1 = N/C
	uint8_t			reserved[2];	///< 2 bytes (packing)
} BS2WiegandTamperInput;

enum{
	BS2_WIEGAND_DEVICE_BUZZER_NUM = 3,
};

/**
 *  BS2WiegandLedStatus
 */
typedef struct{
	BS2_DEVICE_ID	deviceID;		///< 4 bytes
	uint8_t			portIndex;		///< 1 byte
	
	uint16_t		duration;		///< 2 bytes
	uint8_t			reserved[1];	///< 1 bytes (packing)
} BS2WiegandLedOutput;

/**
 *  BS2WiegandBuzzerStatus
 */
typedef struct{
	BS2_DEVICE_ID	deviceID;		///< 4 bytes
	uint8_t			portIndex;		///< 1 byte
	
	uint8_t			buzzerCount;	///< 1 byte  (0 ~ BS2_WIEGAND_DEVICE_BUZZER_NUM)
	uint8_t			reserved[2];	///< 2 bytes (packing)
	struct {
		uint16_t	onDuration;
		uint16_t	offDuration;
	} buzzers[BS2_WIEGAND_DEVICE_BUZZER_NUM]; ///< 12 bytes
} BS2WiegandBuzzerOutput;

enum {
	BS2_WIEGAND_STATUS_NORMAL,
	BS2_WIEGAND_STATUS_SUCCESS,
	BS2_WIEGAND_STATUS_FAIL,
	
	BS2_WIEGAND_STATUS_NUM,
};

/**
 *  BS2WiegandDeviceConfig
 */
typedef struct{
	BS2WiegandTamperInput	tamper;	
	BS2WiegandLedOutput		led[BS2_WIEGAND_STATUS_NUM];
	BS2WiegandBuzzerOutput	buzzer[BS2_WIEGAND_STATUS_NUM];
	
	uint32_t				reserved[32];
} BS2WiegandDeviceConfig;

#endif	// __BS2_WIEGAND_DEVICE_CONFIG_H__
