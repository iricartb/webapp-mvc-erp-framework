/**
 *  System Configuration Definitions
 *
 *  @author jylee@suprema.co.kr
 *  @see
 */

/*
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __BS2_TNA_CONFIG__
#define __BS2_TNA_CONFIG__

#include "../BS2Types.h"

enum {
	//tnaMode
	BS2_TNA_UNUSED = 0,
	BS2_TNA_BY_USER = 1,
	BS2_TNA_BY_SCHEDULE = 2,
	BS2_TNA_LAST_CHOICE = 3,
	BS2_TNA_FIXED = 4,

	// tnaCode
	BS2_TNA_UNSPECIFIED = 0,
	BS2_TNA_CHECK_IN		= 1,
	BS2_TNA_CHECK_OUT		= 2,
	BS2_TNA_IN				= 3,
	BS2_TNA_OUT			= 4,
	BS2_TNA_LUNCH_IN		= 5,
	BS2_TNA_LUNCH_OUT		= 6,
	BS2_TNA_VACATION_IN	= 7,
	BS2_TNA_VACATION_OUT	= 8,
	BS2_TNA_BREAK_IN		= 9,
	BS2_TNA_BREAK_OUT		= 10,
	BS2_TNA_BUSINESS_TRIP_IN		= 11,
	BS2_TNA_BUSINESS_TRIP_OUT		= 12,

	BS2_MAX_TNA_CODE		= 16,
};

typedef struct {
	uint8_t tnaMode;			///< 1 byte
	uint8_t tnaCode;			///< 1 byte
	BS2_BOOL tnaRequired;		///< 1 byte
	uint8_t reserved[1];		///< 1 byte (packing)

	BS2_SCHEDULE_ID tnaSchedule[BS2_MAX_TNA_CODE];
	BS2_BOOL tnaEnabled[BS2_MAX_TNA_CODE];

	uint8_t reserved2[32];		///< 32 bytes (reserved)
} BS2TNAConfig;

#endif /* __BS2_TNA_CONFIG__ */
