/**
 * BS2InputConfig.h
 *
 *  Created on: 2015. 3. 16.
 *      Author: yhlee
 */

/*
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */
 
#ifndef __BS2_INPUT_CONFIG_H__
#define __BS2_INPUT_CONFIG_H__

enum{
	BS2_MAX_INPUT_NUM =	16,
};

enum{
	BS2_INPUT_TYPE_NORMAL,
	BS2_INPUT_TYPE_SUPERVISERD,
};

typedef struct{
	uint16_t	minValue; 	///< 0 ~ 3300 (0 ~ 3.3v)
	uint16_t	maxValue;	///< 0 ~ 3300 (0 ~ 3.3v)
} BS2SVInputRange;

/**
 *	BS2SupervisedInputConfig
 */
typedef struct {
	BS2SVInputRange shortInput;
	BS2SVInputRange openInput;
	BS2SVInputRange onInput;
	BS2SVInputRange offInput;
} BS2SupervisedInputConfig;

/**
 *	BS2InputConfig
 */
typedef struct{
	uint8_t		numInputs;		///< 1 byte
	uint8_t		reserved[3];	///< 3 bytes

	struct {
		uint8_t		portIndex;		///< 1 byte
		BS2_BOOL	enabled;		///< 1 byte
		uint8_t		type;			///< 1 byte
		uint8_t		reserved[1];	///< 1 byte (packing)

		BS2SupervisedInputConfig	config;
	} inputs[BS2_MAX_INPUT_NUM];
} BS2InputConfig;

#endif	/* __BS2_INPUT_CONFIG_H__ */