/**
 *  System Configuration Definitions
 *
 *  @author jylee@suprema.co.kr
 *  @see
 */

/*
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __BS2_SYSTEM_CONFIG_H__
#define __BS2_SYSTEM_CONFIG_H__

#include "../BS2Types.h"
#include "BS2DisplayConfig.h"

/**
 *	BS2SystemConfig
 */
typedef struct {
#if 0
	char tnaLabel[BS2_MAX_TNA_KEY][BS2_MAX_TNA_LABEL_LEN];
#else
	uint8_t notUsed[16 * 16 * 3];
#endif

	int32_t timezone;		///< 4 bytes (offset of GMT in second)

	BS2_BOOL syncTime;		///< 1 bytes (sync time with server)
	BS2_BOOL serverSync;	///< 1 bytes
	BS2_BOOL deviceLocked;	/// 1 bytes
	BS2_BOOL useInterphone;	///< 1 bytes

	BS2_BOOL useUSBConnection;	///< 1 bytes
	uint8_t reserved1[31];	///< 31 bytes (reserved)
} BS2SystemConfig;

#endif	// __BS2_SYSTEM_CONFIG_H__
