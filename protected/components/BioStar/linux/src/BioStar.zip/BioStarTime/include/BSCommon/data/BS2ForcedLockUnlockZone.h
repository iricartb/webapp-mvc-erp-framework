/*
 * BS2ForcedLockUnlockZone.h
 *
 *  Created on: 2014. 12. 9.
 *      Author: smlee
 */

#ifndef BS2FORCEDLOCKUNLOCKZONE_H_
#define BS2FORCEDLOCKUNLOCKZONE_H_

#include "../BS2Types.h"
#include "BS2Zone.h"

enum {
	BS2_MAX_DOORS_IN_FORCED_LOCK_UNLOCK_ZONE = 128,
	BS2_MAX_BYPASS_GROUPS_IN_FORCED_LOCK_UNLOCK_ZONE = 16,
	BS2_MAX_UNLOCK_GROUPS_IN_FORCED_LOCK_UNLOCK_ZONE = 16,
};

typedef struct BS2ForcedLockUnlockZone {
	BS2_ZONE_ID zoneID;
	char name[BS2_MAX_ZONE_NAME_LEN];

	BS2_SCHEDULE_ID lockScheduleID;
	BS2_SCHEDULE_ID unlockScheduleID;

	BS2_BOOL bidirectionalLock;
	uint8_t reserved[3];

	uint8_t numDoors;
	uint8_t numBypassGroups;
	uint8_t numUnlockGroups;
	uint8_t reserved2[5];

	BS2_DOOR_ID doorIDs[BS2_MAX_DOORS_IN_FORCED_LOCK_UNLOCK_ZONE];
	BS2_ACCESS_GROUP_ID bypassGroupIDs[BS2_MAX_BYPASS_GROUPS_IN_FORCED_LOCK_UNLOCK_ZONE];
	BS2_ACCESS_GROUP_ID unlockGroupIDs[BS2_MAX_UNLOCK_GROUPS_IN_FORCED_LOCK_UNLOCK_ZONE];
};

#endif /* BS2FORCEDLOCKUNLOCKZONE_H_ */
