/*
 * BS_Errno.h
 *
 *  Created on: 2015. 4. 27.
 *      Author: scpark
 */

#ifndef CORE_JNI_SRC_BS_ERRNO_H_
#define CORE_JNI_SRC_BS_ERRNO_H_

#define BS_SDK_SUCCESS                                      1
#define BS_SDK_DURESS_SUCCESS                               2
#define BS_SDK_FIRST_AUTH_SUCCESS                           3
#define BS_SDK_SECOND_AUTH_SUCCESS                          4
#define BS_SDK_DUAL_AUTH_SUCCESS                            5

// Communication errors
#define BS_SDK_ERROR_CANNOT_OPEN_SOCKET                     -101
#define BS_SDK_ERROR_CANNOT_CONNECT_SOCKET                  -102
#define BS_SDK_ERROR_CANNOT_LISTEN_SOCKET                   -103
#define BS_SDK_ERROR_CANNOT_ACCEPT_SOCKET                   -104
#define BS_SDK_ERROR_CANNOT_READ_SOCKET                     -105
#define BS_SDK_ERROR_CANNOT_WRITE_SOCKET                    -106
#define BS_SDK_ERROR_SOCKET_IS_NOT_CONNECTED                -107
#define BS_SDK_ERROR_SOCKET_IS_NOT_OPEN                     -108
#define BS_SDK_ERROR_SOCKET_IS_NOT_LISTENED                 -109
#define BS_SDK_ERROR_SOCKET_IN_PROGRESS                     -110

// Packet errors
#define BS_SDK_ERROR_INVALID_PARAM                          -200
#define BS_SDK_ERROR_INVALID_PACKET                         -201
#define BS_SDK_ERROR_INVALID_DEVICE_ID                      -202
#define BS_SDK_ERROR_INVALID_DEVICE_TYPE                    -203
#define BS_SDK_ERROR_PACKET_CHECKSUM                        -204
#define BS_SDK_ERROR_PACKET_INDEX                           -205
#define BS_SDK_ERROR_PACKET_COMMAND                         -206
#define BS_SDK_ERROR_PACKET_SEQUENCE                        -207
#define BS_SDK_ERROR_NO_PACKET                              -209

//Fingerprint errors
#define BS_SDK_ERROR_EXTRACTION_FAIL                        -300
#define BS_SDK_ERROR_VERIFY_FAIL                            -301
#define BS_SDK_ERROR_IDENTIFY_FAIL                          -302
#define BS_SDK_ERROR_FINGERPRINT_CAPTURE_FAIL               -304
#define BS_SDK_ERROR_FINGERPRINT_SCAN_TIMEOUT               -305
#define BS_SDK_ERROR_FINGERPRINT_SCAN_CANCELLED             -306
#define BS_SDK_ERROR_NOT_SAME_FINGERPRINT                   -307
#define BS_SDK_ERROR_EXTRACTION_LOW_QUALITY                 -308
#define BS_SDK_ERROR_CAPTURE_LOW_QUALITY                    -309
#define BS_SDK_ERROR_CANNOT_FIND_FINGERPRINT                -310

//File I/O errors
#define BS_SDK_ERROR_CANNOT_OPEN_DIR                        -400
#define BS_SDK_ERROR_CANNOT_OPEN_FILE                       -401
#define BS_SDK_ERROR_CANNOT_WRITE_FILE                      -402
#define BS_SDK_ERROR_CANNOT_SEEK_FILE                       -403
#define BS_SDK_ERROR_CANNOT_READ_FILE                       -404
#define BS_SDK_ERROR_CANNOT_GET_STAT                        -405
#define BS_SDK_ERROR_CANNOT_GET_SYSINFO                     -406
#define BS_SDK_ERROR_DATA_MISMATCH                          -407

//Util errors
#define BS_SDK_ERROR_NOT_SUPPORTED                          -600
#define BS_SDK_ERROR_TIMEOUT                                -601

//Database errors
#define BS_SDK_ERROR_INVALID_DATA_FILE                      -700
#define BS_SDK_ERROR_INVALID_SLOT_NO                        -702
#define BS_SDK_ERROR_INVALID_SLOT_DATA						-703
#define BS_SDK_ERROR_CANNOT_INIT_DB                         -704
#define BS_SDK_ERROR_DUPLICATE_ID                           -705
#define BS_SDK_ERROR_USER_FULL                              -706
#define BS_SDK_ERROR_FINGERPRINT_FULL                       -708
#define BS_SDK_ERROR_DUPLICATE_CARD                         -709
#define BS_SDK_ERROR_CARD_FULL                              -710
#define BS_SDK_ERROR_NO_VALID_HDR_FILE                      -711
#define BS_SDK_ERROR_INVALID_LOG_FILE						-712
#define BS_SDK_ERROR_CANNOT_FIND_USER                       -714
#define BS_SDK_ERROR_ACCESS_LEVEL_FULL                      -715
#define BS_SDK_ERROR_INVALID_USER_ID                        -716
#define BS_SDK_ERROR_BLACKLIST_FULL                         -717
#define BS_SDK_ERROR_USER_NAME_FULL                         -718
#define BS_SDK_ERROR_USER_IMAGE_FULL                        -719
#define BS_SDK_ERROR_USER_IMAGE_SIZE_TOO_BIG                -720
#define BS_SDK_ERROR_SLOT_DATA_CHECKSUM                     -721
#define BS_SDK_ERROR_CANNOT_UPDATE_FINGERPRINT              -722
#define BS_SDK_ERROR_DOOR_SCHEDULE_FULL                     -726
#define BS_SDK_ERROR_DB_SLOT_FULL                           -727
#define BS_SDK_ERROR_ACCESS_GROUP_FULL                      -728
#define BS_SDK_ERROR_HOLIDAY_GROUP_FULL                     -731
#define BS_SDK_ERROR_HOLIDAY_FULL                           -732
#define BS_SDK_ERROR_TIME_PERIOD_FULL                       -733
#define BS_SDK_ERROR_NO_BIOMETRIC_CREDENTIAL                -735
#define BS_SDK_ERROR_NO_PIN_CREDENTIAL                      -737
#define BS_SDK_ERROR_NO_BIOMETRIC_PIN_CREDENTIAL            -738
#define BS_SDK_ERROR_NO_USER_IMAGE                          -740
#define BS_SDK_ERROR_OPERATOR_FULL                          -743

//Config errors
#define BS_SDK_ERROR_INVALID_CONFIG                         -800
#define BS_SDK_ERROR_INVALID_CONFIG_DATA                    -804
#define BS_SDK_ERROR_INVALID_CONFIG_INDEX                   -806

//Device errors
#define BS_SDK_ERROR_CANNOT_SCAN_FINGER                     -900
#define BS_SDK_ERROR_CANNOT_SCAN_CARD                       -901
#define BS_SDK_ERROR_CANNOT_FIND_DEVICE                     -907

//Door errors
#define BS_SDK_ERROR_CANNOT_FIND_DOOR                       -1000
#define BS_SDK_ERROR_DOOR_FULL                              -1001
#define BS_SDK_ERROR_CANNOT_LOCK_DOOR                       -1002
#define BS_SDK_ERROR_CANNOT_UNLOCK_DOOR                     -1003

//Access control errors
#define BS_SDK_ERROR_ACCESS_RULE_VIOLATION                  -1100
#define BS_SDK_ERROR_DISABLED                               -1101
#define BS_SDK_ERROR_NOT_YET_VALID                          -1102
#define BS_SDK_ERROR_EXPIRED                                -1103
#define BS_SDK_ERROR_BLACKLIST                              -1104
#define BS_SDK_ERROR_CANNOT_FIND_ACCESS_GROUP               -1105
#define BS_SDK_ERROR_CANNOT_FIND_ACCESS_LEVEL               -1106
#define BS_SDK_ERROR_CANNOT_FIND_ACCESS_SCHEDULE            -1107
#define BS_SDK_ERROR_CANNOT_FIND_HOLIDAY_GROUP              -1108

#define BS_SDK_ERROR_AUTH_TIMEOUT                           -1110
#define BS_SDK_ERROR_DUAL_AUTH_TIMEOUT                      -1111
#define BS_SDK_ERROR_INVALID_AUTH_MODE                      -1112
#define BS_SDK_ERROR_AUTH_UNEXPECTED_USER                   -1113
#define BS_SDK_ERROR_AUTH_UNEXPECTED_CREDENTIAL             -1114
#define BS_SDK_ERROR_DUAL_AUTH_FAIL                         -1115
#define BS_SDK_ERROR_BIOMETRIC_AUTH_REQUIRED                -1116
#define BS_SDK_ERROR_PIN_AUTH_REQUIRED                      -1118
#define BS_SDK_ERROR_BIOMETRIC_OR_PIN_AUTH_REQUIRED         -1119
#define BS_SDK_ERROR_TNA_CODE_REQUIRED                      -1120

//Zone errors
#define BS_SDK_ERROR_CANNOT_FIND_ZONE                       -1200
#define BS_SDK_ERROR_ZONE_FULL                              -1201
#define BS_SDK_ERROR_HARD_APB_VIOLATION                     -1202
#define BS_SDK_ERROR_SOFT_APB_VIOLATION                     -1203
#define BS_SDK_ERROR_HARD_TIMED_APB_VIOLATION               -1204
#define BS_SDK_ERROR_SOFT_TIMED_APB_VIOLATION               -1205
#define BS_SDK_ERROR_FORCED_LOCK_VIOLATION                  -1206
#define BS_SDK_ERROR_FORCED_UNLOCK_VIOLATION                -1207
#define BS_SDK_ERROR_SET_FIRE_ALARM                         -1208

//Card errors
#define BS_SDK_ERROR_CARD_IO                                -1300
#define BS_SDK_ERROR_CARD_CANNOT_READ_DATA                  -1303
#define BS_SDK_ERROR_CARD_CANNOT_WRITE_DATA                 -1305
#define BS_SDK_ERROR_CARD_READ_TIMEOUT                      -1306
#define BS_SDK_ERROR_CARD_READ_CANCELLED                    -1307
#define BS_SDK_ERROR_CANNOT_FIND_CARD                       -1310

//ETC.
#define BS_SDK_ERROR_ALLOC_MEM                              -2002
#define BS_SDK_ERROR_CANNOT_UPGRADE                         -2003

#define BS_SDK_ERROR_NULL_POINTER                           -10000
#define BS_SDK_ERROR_UNINITIALIZED                          -10001
#define BS_SDK_ERROR_CANNOT_RUN_SERVICE                     -10002
#define BS_SDK_ERROR_CANCELED                               -10003
#define BS_SDK_ERROR_EXIST                                  -10004
#define BS_SDK_ERROR_ENCRYPT                                -10005
#define BS_SDK_ERROR_DECRYPT                                -10006
#define BS_SDK_ERROR_DEVICE_BUSY							-10007

#endif /* CORE_JNI_SRC_BS_ERRNO_H_ */
