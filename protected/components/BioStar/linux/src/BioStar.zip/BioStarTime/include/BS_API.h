/*
 * BS_API.h
 *
 *  Created on: 2015. 4. 10.
 *      Author: scpark
 */

#ifndef CORE_SRC_BS_API_H_
#define CORE_SRC_BS_API_H_

#include "BSCommon/BS2Types.h"
#include "BSCommon/config/BS2AuthConfig.h"
#include "BSCommon/config/BS2CardConfig.h"
#include "BSCommon/config/BS2DisplayConfig.h"
#include "BSCommon/config/BS2FactoryConfig.h"
#include "BSCommon/config/BS2FingerprintConfig.h"
#include "BSCommon/config/BS2InputConfig.h"
#include "BSCommon/config/BS2IpConfig.h"
#include "BSCommon/config/BS2Rs485Config.h"
#include "BSCommon/config/BS2StatusConfig.h"
#include "BSCommon/config/BS2SystemConfig.h"
#include "BSCommon/config/BS2TnaExtConfig.h"
#include "BSCommon/config/BS2TriggerActionConfig.h"
#include "BSCommon/config/BS2WiegandConfig.h"
#include "BSCommon/config/BS2WiegandDeviceConfig.h"
#include "BSCommon/config/BS2WlanConfig.h"
//#include "BSCommon/data/BS2AccessGroup.h"
//#include "BSCommon/data/BS2AccessLevel.h"
//#include "BSCommon/data/BS2Action.h"
//#include "BSCommon/data/BS2AntiPassbackZone.h"
//#include "BSCommon/data/BS2BlackList.h"
#include "BSCommon/data/BS2Card.h"
//#include "BSCommon/data/BS2DataHeader.h"
//#include "BSCommon/data/BS2DaySchedule.h"
//#include "BSCommon/data/BS2Device.h"
//#include "BSCommon/data/BS2Door.h"
//#include "BSCommon/data/BS2Error.h"
#include "BSCommon/data/BS2Event.h"
#include "BSCommon/data/BS2Face.h"
#include "BSCommon/data/BS2Fingerprint.h"
//#include "BSCommon/data/BS2FireAlarmZone.h"
//#include "BSCommon/data/BS2ForcedLockUnlockZone.h"
//#include "BSCommon/data/BS2Holiday.h"
//#include "BSCommon/data/BS2Resource.h"
//#include "BSCommon/data/BS2Rs485Channel.h"
//#include "BSCommon/data/BS2Rs485SlaveDeviceSetting.h"
//#include "BSCommon/data/BS2Schedule.h"
//#include "BSCommon/data/BS2TimedAntiPassbackZone.h"
//#include "BSCommon/data/BS2Trigger.h"
#include "BSCommon/data/BS2User.h"
//#include "BSCommon/data/BS2Zone.h"

#ifdef BS_SDK_V2_DLL
#define BS_API_EXPORT __declspec(dllimport)
#define BS_CALLING_CONVENTION __cdecl
#else
#define BS_API_EXPORT
#define BS_CALLING_CONVENTION
#endif


#pragma pack(1)

typedef struct
{
	BS2User user;
	BS2UserSetting setting;
	BS2_USER_NAME user_name;
	BS2_USER_PIN pin;
	BS2Card* cardObjs;
	BS2Fingerprint* fingerObjs;
	BS2Face* faceObjs;
}BS2UserBlob;

typedef struct
{
	BS2_DEVICE_ID id;
	BS2_DEVICE_TYPE type;
	BS2_CONNECTION_MODE connectionMode;
    uint32_t ipv4Address;
    BS2_PORT port;
    uint32_t maxNumOfUser;
	uint8_t userNameSupported;
	uint8_t userPhotoSupported;
	uint8_t pinSupported;
	uint8_t cardSupported;
	uint8_t fingerSupported;
	uint8_t faceSupported;
	uint8_t wlanSupported;
	uint8_t tnaSupported;
	uint8_t triggerActionSupported;
	uint8_t wiegandSupported;
}BS2SimpleDeviceInfo;
#pragma pack()

typedef void (*OnDeviceFound)(BS2_DEVICE_ID deviceId);
typedef void (*OnDeviceAccepted)(BS2_DEVICE_ID deviceId);
typedef void (*OnDeviceConnected)(BS2_DEVICE_ID deviceId);
typedef void (*OnDeviceDisconnected)(BS2_DEVICE_ID deviceId);
typedef void (*OnReadyToScan)(BS2_DEVICE_ID deviceId, uint32_t sequence);

#ifdef __cplusplus
extern "C"
{
#endif

BS_API_EXPORT void* BS_CALLING_CONVENTION BS2_AllocateContext();
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_Initialize(void* context);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetDeviceEventListener(void* context,
                                            OnDeviceFound ptrDeviceFound,
											OnDeviceAccepted ptrDeviceAccepted,
                                            OnDeviceConnected ptrDeviceConnected,
                                            OnDeviceDisconnected ptrDeviceDisconnected);
BS_API_EXPORT void BS_CALLING_CONVENTION BS2_ReleaseContext(void* context);
BS_API_EXPORT void BS_CALLING_CONVENTION BS2_ReleaseObject(void* object);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SearchDevices(void* context);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetDevices(void* context, BS2_DEVICE_ID** deviceListObj, uint32_t* numDevice);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetDeviceInfo(void* context, BS2_DEVICE_ID deviceId, BS2SimpleDeviceInfo* deviceInfo);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_ConnectDevice(void* context, BS2_DEVICE_ID deviceId);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_ConnectDeviceViaIP(void* context, const char* deviceAddress, BS2_PORT defaultDevicePort, BS2_DEVICE_ID* deviceId);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_DisconnectDevice(void* context, BS2_DEVICE_ID deviceId);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_MakePinCode(void* context, char* plaintext, unsigned char* ciphertext);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetLog(void* context,
													BS2_DEVICE_ID deviceId,
													BS2_EVENT_ID eventId,
													uint32_t amount,
													BS2Event** logsObj,
													uint32_t* numLog);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetFilteredLog(void* context,
															BS2_DEVICE_ID deviceId,
															char* uid,
															BS2_EVENT_CODE eventCode,
															BS2_TIMESTAMP start,
															BS2_TIMESTAMP end,
															uint8_t tnakey,
															BS2Event** logsObj,
															uint32_t* numLog);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_ClearLog(void* context, BS2_DEVICE_ID deviceId);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetUserList(void* context,
														BS2_DEVICE_ID deviceId,
														char** uidsObj,
														uint32_t* numUid);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetUserInfos(void* context, BS2_DEVICE_ID deviceId, char* uids, uint32_t uidCount, BS2UserBlob* userBlob);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_EnrolUser(void* context, BS2_DEVICE_ID deviceId, BS2UserBlob* userBlob, uint32_t userCount, uint8_t overwrite);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_RemoveUser(void* context, BS2_DEVICE_ID deviceId, char* uids, uint32_t uidCount);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_RemoveAllUser(void* context, BS2_DEVICE_ID deviceId);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_ScanCard(void* context,
													BS2_DEVICE_ID deviceId,
													BS2Card* card,
													OnReadyToScan ptrReadyToScan);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_ScanFingerprint(void* context,
															BS2_DEVICE_ID deviceId,
															BS2Fingerprint* finger,
															uint32_t templateIndex,
															uint32_t quality,
															OnReadyToScan ptrReadyToScan);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_VerifyFingerprint(void* context, BS2_DEVICE_ID deviceId, BS2Fingerprint* finger);

BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetDeviceTime(void* context, BS2_DEVICE_ID deviceId, BS2_TIMESTAMP* gmtTime);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetDeviceTime(void* context, BS2_DEVICE_ID deviceId, BS2_TIMESTAMP gmtTime);

// config api
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetFactoryConfig(void* context, BS2_DEVICE_ID deviceId, BS2FactoryConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetSystemConfig(void* context, BS2_DEVICE_ID deviceId, BS2SystemConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetSystemConfig(void* context, BS2_DEVICE_ID deviceId, BS2SystemConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetAuthConfig(void* context, BS2_DEVICE_ID deviceId, BS2AuthConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetAuthConfig(void* context, BS2_DEVICE_ID deviceId, BS2AuthConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetDisplayConfig(void* context, BS2_DEVICE_ID deviceId, BS2DisplayConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetDisplayConfig(void* context, BS2_DEVICE_ID deviceId, BS2DisplayConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetIPConfig(void* context, BS2_DEVICE_ID deviceId, BS2IpConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetIPConfigViaUDP(void* context, BS2_DEVICE_ID deviceId, BS2IpConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetIPConfig(void* context, BS2_DEVICE_ID deviceId, BS2IpConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetIPConfigViaUDP(void* context, BS2_DEVICE_ID deviceId, BS2IpConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetTNAConfig(void* context, BS2_DEVICE_ID deviceId, BS2TNAConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetTNAConfig(void* context, BS2_DEVICE_ID deviceId, BS2TNAConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetCardConfig(void* context, BS2_DEVICE_ID deviceId, BS2CardConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetCardConfig(void* context, BS2_DEVICE_ID deviceId, BS2CardConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_GetFingerprintConfig(void* context, BS2_DEVICE_ID deviceId, BS2FingerprintConfig* config);
BS_API_EXPORT int BS_CALLING_CONVENTION BS2_SetFingerprintConfig(void* context, BS2_DEVICE_ID deviceId, BS2FingerprintConfig* config);

BS_API_EXPORT const char* BS_CALLING_CONVENTION BS2_Version();

#ifdef __cplusplus
}
#endif


#endif /* CORE_SRC_BS_API_H_ */
