/**
 *  Fire Alarm Zone
 *
 *  @author jylee@suprema.co.kr
 *  @see
 */

/*
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 *
 *  This software is the confidential and proprietary information of
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __BS2_FIRE_ALARM_ZONE_H__
#define __BS2_FIRE_ALARM_ZONE_H__

#include "../BS2Types.h"
#include "BS2Action.h"
#include "BS2Zone.h"

/**
 *  Constants
 */
enum {
	BS2_MAX_DOORS_PER_FIRE_ALARM_ZONE	= 128,
};

typedef struct {
	BS2_DEVICE_ID	deviceID;		///< 4 bytes
	uint8_t			portIndex;		///< 1 byte
	uint8_t			switchType;		///< 1 byte
	uint8_t			reserved[2];	///< 2 bytes (packing)
} BS2FireSensor;

typedef struct {
	BS2_ZONE_ID		zoneID;			///< 4 bytes
	char			name[BS2_MAX_ZONE_NAME_LEN];

	BS2FireSensor	sensor;
	BS2Action	alarm;

	BS2_BOOL alarmed;
	uint8_t			numDoors;		///< 1 byte
	uint8_t			reserved[2];	///< 2 bytes (packing)

	BS2_DOOR_ID		doorIDs[BS2_MAX_DOORS_PER_FIRE_ALARM_ZONE];
} BS2FireAlarmZone;

#endif	// __BS2_FIRE_ALARM_ZONE_H__
