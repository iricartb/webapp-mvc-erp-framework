/*
 * BS2TimedAntiPassbackZone.h
 *
 *  Created on: 2014. 12. 9.
 *      Author: smlee
 */

#ifndef BS2TIMEDANTIPASSBACKZONE_H_
#define BS2TIMEDANTIPASSBACKZONE_H_

#include "../BS2Types.h"
#include "BS2Zone.h"

enum {
	BS2_MAX_READERS_PER_TIMED_APB_ZONE = 128,
	BS2_MAX_BYPASS_GROUPS_PER_TIMED_APB_ZONE = 16,
};

/**
 *  BS2_TIMED_APB_ZONE_TYPE
 */
enum {
	BS2_TIMED_APB_ZONE_HARD		= 0x00,
	BS2_TIMED_APB_ZONE_SOFT		= 0x01,
};

typedef uint8_t BS2_TIMED_APB_ZONE_TYPE;

typedef struct {
	BS2_DEVICE_ID deviceID;			///< 4 bytes
	uint8_t reserved[4];			///< 4 bytes (packing)
} BS2TimedApbMember;

typedef struct {
	BS2_ZONE_ID zoneID;
	char name[BS2_MAX_ZONE_NAME_LEN];

	BS2_TIMED_APB_ZONE_TYPE type;		// 0: hard timed APB, 1: soft timed APB
	uint8_t reserved[3];

	uint32_t resetDuration;		// in seconds, 0: no reset

	uint8_t numReaders;
	uint8_t numBypassGroups;
	uint8_t reserved2[2];

	BS2TimedApbMember readers[BS2_MAX_READERS_PER_TIMED_APB_ZONE];

	BS2_ACCESS_GROUP_ID bypassGroupIDs[BS2_MAX_BYPASS_GROUPS_PER_TIMED_APB_ZONE];

	//TODO: timed APB alarm
} BS2TimedAntiPassbackZone;

#endif /* BS2TIMEDANTIPASSBACKZONE_H_ */
