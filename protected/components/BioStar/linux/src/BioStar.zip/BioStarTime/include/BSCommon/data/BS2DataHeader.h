/**
 *  Configuration Header
 *
 *  @author jylee@suprema.co.kr
 *  @see    
 */

/*  
 *  Copyright (c) 2014 Suprema Co., Ltd. All Rights Reserved.
 * 
 *  This software is the confidential and proprietary information of 
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __BS2_CONFIG_HEADER_H__
#define __BS2_CONFIG_HEADER_H__

#include "../BS2Types.h"

/**
 *	Configuration Type
 */
enum {
	BS2_DATA_MASK_NONE			= 0x0000,
	BS2_DATA_MASK_CARD			= 0x0001,
	BS2_DATA_MASK_DOOR			= 0x0002,
	BS2_DATA_MASK_ZONE			= 0x0004,
	BS2_DATA_MASK_ACCESS_GROUP	= 0x0008,
	BS2_DATA_MASK_ACCESS_LEVEL	= 0x0010,
	BS2_DATA_MASK_SCHEDULE		= 0x0020,
	BS2_DATA_MASK_BLACKLIST		= 0x0040,
	BS2_DATA_MASK_ALL			= 0xFFFF,
};

#endif	// __BS2_CONFIG_HEADER_H__