g++ -m32 main.cpp -o BioStarDisenroll lib/libBS_SDK_V2.so -lpthread && ./BioStarDisenroll
