g++ -m32 main.cpp -o BioStarQuery lib/libBS_SDK_V2.so -lpthread && ./BioStarQuery
