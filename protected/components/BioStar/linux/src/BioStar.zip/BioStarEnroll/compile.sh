g++ -m32 main.cpp -o BioStarEnroll lib/libBS_SDK_V2.so -lpthread && ./BioStarEnroll
