#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>

#include "include/BS_API.h"
#include "include/BS_Errno.h"

#define TRUE 1
#define FALSE 0

#define SUCCESS_CONNECT_DEVICE_STATUS 0
#define ERR_CONNECT_DEVICE_STATUS_1 -1 
#define ERR_CONNECT_DEVICE_STATUS_2 -2 
#define ERR_CONNECT_DEVICE_STATUS_3 -3
      
int initialize();
int connectDevice(char * sDeviceIPAddress, int nDevicePort);
void disconnectDevice();
long convertDateToUnixTimestamp(char * sDate);
char * convertUnixTimestampToDate(long nSeconds);
char * decodeHexString(char * sFingerprint);

void * oBS2Context = NULL;
char * sInputDeviceIPAddress, * sInputIdUser, * sInputCard, * sInputCardCustom, * sInputFingerprint1, * sInputFingerprint2;
int nInputDevicePort;
uint32_t nDeviceId = 0;

using namespace std;

int main(int argc, char ** argv) {
   int nResult;
   
   try {
      if (argc == 8) {
         sInputDeviceIPAddress = argv[1];
         nInputDevicePort = atoi(argv[2]);
         sInputIdUser = argv[3];
         sInputCard = argv[4];
         sInputCardCustom = argv[5];
         sInputFingerprint1 = argv[6];
         sInputFingerprint2 = argv[7];

         if (initialize()) {
            int nConnectDeviceStatus = connectDevice(sInputDeviceIPAddress, nInputDevicePort);
            
            if (nConnectDeviceStatus == SUCCESS_CONNECT_DEVICE_STATUS) {
               BS2UserBlob oUserBlob;
               BS2Card oUserCardList[1];
               BS2Fingerprint oUserFingerprintList[2];
               
               memset(&oUserBlob, 0, sizeof(BS2UserBlob));
               strcpy(oUserBlob.user.userID, sInputIdUser); 
            
               oUserBlob.setting.startTime = 0;
               oUserBlob.setting.endTime = 0;
               oUserBlob.setting.idAuthMode = BS2_AUTH_MODE_NONE;
               oUserBlob.setting.securityLevel = BS2_USER_SECURITY_LEVEL_DEFAULT;
               
               oUserBlob.setting.cardAuthMode = BS2_AUTH_MODE_CARD_ONLY;
               oUserBlob.setting.fingerAuthMode = BS2_AUTH_MODE_BIOMETRIC_ONLY;
               
               // Copy card templates to user header
               if ((strlen(sInputCard) > 0) && (strlen(sInputCardCustom) > 0)) {
                  oUserBlob.user.numCards = 1;
                  oUserCardList[0].type = BS2_CARD_TYPE_UNKNOWN;
                  oUserCardList[0].size = strlen(sInputCard);
                  memcpy(oUserCardList[0].data, sInputCard, strlen(sInputCard));
                  
                  oUserBlob.cardObjs = oUserCardList;
               }
               else oUserBlob.user.numCards = 0;
               
               // Copy fingerprint templates to user header
               if (strlen(sInputFingerprint1) == (BS2_FINGER_TEMPLATE_SIZE * 4)) {
                  oUserBlob.user.numFingers = 1;
                  
                  char * sUserDecodeFingerprint1 = decodeHexString(sInputFingerprint1);
                  oUserFingerprintList[0].index = 0;
                  oUserFingerprintList[0].flag = 0;
                  memcpy(oUserFingerprintList[0].data[0], sUserDecodeFingerprint1, (strlen(sUserDecodeFingerprint1) / 2));
                  memcpy(oUserFingerprintList[0].data[1], (sUserDecodeFingerprint1 + (strlen(sUserDecodeFingerprint1) / 2)), (strlen(sUserDecodeFingerprint1) / 2));
                  
                  if (strlen(sInputFingerprint2) == (BS2_FINGER_TEMPLATE_SIZE * 4)) { 
                     oUserBlob.user.numFingers++;
                      
                     char * sUserDecodeFingerprint2 = decodeHexString(sInputFingerprint2);
                     oUserFingerprintList[1].index = 1;
                     oUserFingerprintList[1].flag = 0;
                     memcpy(oUserFingerprintList[1].data[0], sUserDecodeFingerprint2, (strlen(sUserDecodeFingerprint2) / 2));
                     memcpy(oUserFingerprintList[1].data[1], (sUserDecodeFingerprint2 + (strlen(sUserDecodeFingerprint2) / 2)), (strlen(sUserDecodeFingerprint2) / 2));
                  }
                  
                  oUserBlob.fingerObjs = oUserFingerprintList;
               }
               else oUserBlob.user.numFingers = 0;
               
               nResult = BS2_EnrolUser(oBS2Context, nDeviceId, &oUserBlob, 1, 1);
               if (nResult == BS_SDK_SUCCESS) {
                  cout << "[ SUCCESS ] El usuario con ID: " << sInputIdUser << " ha sido registrado correctamente del dispositivo con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << "." << endl; 
               }
               else cout << "[ ERROR ] No se ha podido registrar el usuario con ID: " << sInputIdUser << " del dispositivo con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ".\r\nCodigo de Error: " << nResult << "\r\n" << endl; 
               
               disconnectDevice();
            }
            else {
               if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_1) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". La funcion BS2_ConnectDeviceViaIP ha fallado.\r\n" << endl;    
               else if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_2) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". La funcion BS2_GetDeviceInfo ha fallado.\r\n" << endl;    
               else if (nConnectDeviceStatus == ERR_CONNECT_DEVICE_STATUS_3) cout << "[ ERROR ] No se ha podido establecer conexion con el host: " << sInputDeviceIPAddress << " y puerto: " << nInputDevicePort << ". El dispositivo no es un Biostar Entry Plus.\r\n" << endl;     
            }
            
            BS2_ReleaseContext(oBS2Context);
         }
         else cout << "[ ERROR ] No se ha podido inicializar el Biostar.\r\n" << endl;
      }
      else cout << "[ ERROR ] El numero de argumentos es incorrecto.\r\n\n\t* Argumentos: IP_Address Port UserID CardID CardCustomID FingerprintTemplate1 FingerprintTemplate2\r\n" << endl;
   } catch(exception& oException) {
      cout << oException.what() << endl;  
   }
}

int initialize() {
   oBS2Context = BS2_AllocateContext();   
   
   if (oBS2Context != NULL) {
      int nResult = BS2_Initialize(oBS2Context);
      
      if (nResult == BS_SDK_SUCCESS) return TRUE;
      else return FALSE;
   } 
}

int connectDevice(char * sDeviceIPAddress, int nDevicePort) { 
   BS2SimpleDeviceInfo oDeviceInformation;
   int nResult = BS2_ConnectDeviceViaIP(oBS2Context, sDeviceIPAddress, nDevicePort, &nDeviceId);
   
   if (nResult == BS_SDK_SUCCESS) {
      nResult = BS2_GetDeviceInfo(oBS2Context, nDeviceId, &oDeviceInformation);
      if (nResult == BS_SDK_SUCCESS) {
         if ((oDeviceInformation.type == BS2_DEVICE_TYPE_BIOENTRY_PLUS) || (oDeviceInformation.type == BS2_DEVICE_TYPE_BIOLITE_NET)) {
            return SUCCESS_CONNECT_DEVICE_STATUS;
         }   
         else return ERR_CONNECT_DEVICE_STATUS_3;
      }
      else return ERR_CONNECT_DEVICE_STATUS_2;
   }
   else return ERR_CONNECT_DEVICE_STATUS_1;
}

void disconnectDevice() { 
   BS2_DisconnectDevice(oBS2Context, nDeviceId);   
}

long convertDateToUnixTimestamp(char * sDate) {
   struct tm oTimeStamp;

   strptime(sDate, "%Y-%m-%d %H:%M:%S", &oTimeStamp);
   
   oTimeStamp.tm_sec += 3600;
   
   return mktime(&oTimeStamp);
}

char * convertUnixTimestampToDate(long nSeconds) {
   struct tm oTimeStamp;
   char * sDate = (char *) malloc(sizeof(char) * 20);
   
   oTimeStamp.tm_sec += nSeconds;
   
   strftime(sDate, sizeof(sDate), "%Y-%m-%d %H:%M:%S", &oTimeStamp);

   return sDate;
}

char * decodeHexString(char * sFingerprint) {
   char * sDecodeFingerprint = (char *) malloc(sizeof(char) * BS2_FINGER_TEMPLATE_SIZE * 2);
   char * sFingerprintCodeHex = (char *) malloc(sizeof(char) * 2);
   
   for(int i = 0; i < (strlen(sFingerprint) / 2); i++) {
      strncpy(sFingerprintCodeHex, (sFingerprint + (i * 2)), 2); 
      
      sDecodeFingerprint[i] = strtoul(sFingerprintCodeHex, 0, 16);   
   }
   
   return sDecodeFingerprint;
}